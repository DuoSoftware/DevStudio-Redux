<?php 

	$mainDomain="duoworld.duoweb.info";
	$authURI="http://duoworld.duoweb.info:3048/";
	$objURI="http://duoworld.duoweb.info:3000/";
	$pentURI="http://104.236.192.147:8080/";
	$homeURI="/duodigin/home.html"
?>