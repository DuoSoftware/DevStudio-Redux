<?php

//include ("include/config.php");

function createSessionDmian(){
	$Host = strtolower($_SERVER['HTTP_HOST']);
	//echo "$authURI";
	if(isset($_COOKIE['securityToken'])){
		$obj=getSession($_COOKIE['securityToken'],"");
		//ho $_COOKIE['securityToken'];
		var_dump($obj);
		//it();
		if(isset($obj))
		{
			$_SESSION['userObject']=$obj;
			echo "string 1";
			//setcookie('authData')
			if(!isset($_COOKIE['authData'])){
				echo "cookie not set";
				$obj=getSession($_COOKIE['securityToken'],$Host);
				var_dump($obj);
			    if( isset($obj) && $obj->SecurityToken!=""){
			    	echo "set....1";
			    	$_SESSION[$Host]=$obj;
			    	setcookie("securityToken", $obj->SecurityToken);
			    	setcookie("authData", json_encode($obj));
			    	return true;
			    }
			    else
			    {
			    	return false;
			    }
			}else{
				return true;
			}
		}else{
			return false;
		}	
	}
	else
	{
		return false;
	}
}

function getSession($securityToken,$domain){
	$ch=curl_init();
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'securityToken : ""',
	'X-Apple-Store-Front: 143444,12'
	));
	if($domain==""){
		$domain="Nil";
	}

	curl_setopt($ch, CURLOPT_URL, $GLOBALS['authURI'].'/GetSession/'.$securityToken.'/'.$domain.'');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	$obj = json_decode($data);
	return $obj;
}


function getURI(){
			if(!isset($_COOKIE["securityToken"])){
				header("Location: s.php?r=index.php");
				exit();
			}
			$uri=$GLOBALS['objURI'];
		    $serchfild=strtolower($_SERVER['HTTP_HOST']);
			$ch=curl_init();
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		    'SecurityToken :'.$_COOKIE['securityToken'],
		    'X-Apple-Store-Front: 143444,12'
		    ));
			curl_setopt($ch, CURLOPT_URL, $GLOBALS['authURI'].'/tenant/GetTenant/'.$serchfild);
			//curl_setopt($ch, CURLOPT_URL, $uri.'/duosoftware.com/application?keyword='.$serchfild.'');
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    $data = curl_exec($ch);
		    //var_dump($GLOBALS['authURI'].'/tenant/GetTenant/'.$serchfild);
		   	//var_dump($data);
		   	//var_dump($_COOKIE['securityToken']);
		   	//exit();
		    $obj = json_decode($data);
		    //var_dump( $obj);
		    //exit();
		    if (isset($obj)){
		    	if($obj->TenantID!=""){
		    		setcookie("tenantData", json_encode($obj));
		    		header("Location: /".$obj->Shell."");
		    	}else{
		    		include("t.php");
		    	}	

		    }else{
		    	include("t.php");
		    }
}
?>