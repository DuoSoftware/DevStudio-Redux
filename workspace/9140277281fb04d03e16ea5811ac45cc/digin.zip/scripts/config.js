angular.module('configuration', [])
 
 
    .constant('Digin_Extended_Analytics','http://104.236.192.147:8080/DuoDigin/api/repos/xanalyzer/service/selectSchema?ts=1432813521945')
    .constant('Digin_Extended_Reports','http://104.236.192.147:8080/DuoDigin/api/repos/pentaho-interactive-reporting/prpti.new?ts=1432879514549')
    .constant('Digin_Extended_Dashboard','http://104.236.192.147:8080/DuoDigin/api/repos/dashboards/editor?ts=1432880580357')
    .constant('Digin_Extended_Datasource','http://104.236.192.147:8080/DuoDigin/plugin/data-access/api/connection/list?ts=1432880662383')
    .constant('Digin_AnalyzerViewer',' http://104.236.192.147:8080/DuoDigin/api/repos/%3Ahome%') 
    .constant('Digin_ReportViewer','http://104.236.192.147:8080/DuoDigin/api/repos/%3Ahome%')
    .constant('Digin_DashboardViewer','http://104.236.192.147:8080/DuoDigin/api/repos/%3Ahome%')
    .constant('Digin_Base_URL','http://localhost/dign/duodigin/')
 


